package pnu.edu.shape;

public interface AreaComputable {
    public int compareTo(final AreaComputable other);
    public float getSize();
}
