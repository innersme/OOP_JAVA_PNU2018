package pnu.edu.editor;

public enum SortKind {
    ASCENDING, DESCENDING
};
